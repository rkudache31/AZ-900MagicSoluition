from flask import Flask, jsonify
from flask_cors import CORS
from azure.data.tables import TableClient
from azure.storage.queue import QueueClient, QueueServiceClient
from azure.core.exceptions import ResourceNotFoundError
from datetime import datetime
import logging
import os

app = Flask(__name__)
CORS(app)

account_name = ''
account_key = ''
stg_name = ''
connection_string_queue = f"DefaultEndpointsProtocol=https;AccountName={account_name};AccountKey={account_key};EndpointSuffix=core.windows.net"
connection_string_table = ''
table_name = 'mst'

@app.route('/process_messages', methods=['GET'])
def process_messages():
    queue_service_client = QueueServiceClient.from_connection_string(connection_string_queue)
    queue_client = queue_service_client.get_queue_client(stg_name)
    table_client = TableClient.from_connection_string(connection_string_table, table_name)

    try:
        messages = queue_client.receive_messages(messages_per_page=5)  # Adjust as needed

        message_count = 0  # Counter for counting messages received
        processed_messages = []  # List to store processed message details

        for message_batch in messages.by_page():
            for message in message_batch:
                logging.info(f"Message ID: {message.id}")
                logging.info(f"Message Body: {message.content}")
                logging.info(f"Dequeue Count: {message.dequeue_count}")
                logging.info("")

                partition_key = 'Messagedata'  # Specify your partition key
                row_key = f"RowKey-{datetime.now().isoformat()}"

                entity = {
                    'PartitionKey': partition_key,
                    'RowKey': row_key,
                    'Id': str(message.id),  # Convert id to string (RowKey must be a string)
                    'msgbody': str(message.content),
                    'Timestamp': datetime.now().isoformat()
                }

                table_client.upsert_entity(entity)
                queue_client.delete_message(message.id, message.pop_receipt)
                message_count += 1  # Increment the message count

                processed_messages.append({
                    'MessageID': message.id,
                    'MessageBody': message.content,
                    'DequeueCount': message.dequeue_count
                })

        if message_count == 0:
            logging.info(f"No messages available in the queue '{stg_name}'")
            return jsonify({'status': 'No messages available'}), 200
        else:
            logging.info(f"Received {message_count} message(s) from the queue '{stg_name}'")
            return jsonify({'status': f'Received {message_count} message(s)', 'messages': processed_messages}), 200

    except ResourceNotFoundError:
        logging.error(f"The queue '{stg_name}' does not exist or is not accessible.")
        return jsonify({'error': 'Queue not found'}), 404
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)

