from flask import Flask, request, jsonify
from azure.storage.queue import QueueServiceClient
from flask_cors import CORS
app = Flask(__name__)
CORS(app)  # Enable CORS for the entire app

# Azure Storage account credentials
account_name = 'demoaztest900'
account_key = '2AyBfuOjj89ytf0Tln6HH+TeYEtK76G3lKc+jMGxj5yf+tI533f0kgpulLTkNdclVT8XlUZ6GZhS+AStN+DL6Q=='
queue_name = 'demo1'

# Create a connection to the Queue Service
connection_string = f"DefaultEndpointsProtocol=https;AccountName={account_name};AccountKey={account_key};EndpointSuffix=core.windows.net"
queue_service_client = QueueServiceClient.from_connection_string(connection_string)

# Get a client to interact with the specific queue
queue_client = queue_service_client.get_queue_client(queue_name)

@app.route('/', methods=['GET'])
def index():
    return "Welcome to the Azure Queue Service!"

@app.route('/send_message', methods=['POST'])
def send_message():
    # Extract message content from request body
    if not request.json or 'message' not in request.json:
        return jsonify({"error": "Invalid request. 'message' field missing in JSON body."}), 400
    
    message_content = request.json['message']

    try:
        # Add a message to the queue
        queue_client.send_message(message_content)
        return jsonify({"message": f"Message '{message_content}' added to the queue '{queue_name}'"}), 200

    except Exception as e:
        return jsonify({"error": f"Failed to add message to the queue: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
