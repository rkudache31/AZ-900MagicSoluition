from azure.data.tables import TableClient
from datetime import datetime
from azure.storage.queue import QueueClient
from azure.storage.queue import QueueServiceClient
from azure.core.exceptions import ResourceNotFoundError
# Replace these variables with your Azure Storage account name and key
account_name = 'demoaztest900'
account_key = '2AyBfuOjj89ytf0Tln6HH+TeYEtK76G3lKc+jMGxj5yf+tI533f0kgpulLTkNdclVT8XlUZ6GZhS+AStN+DL6Q=='
stg_name = 'demo1'

# Create a connection to the Queue Service
connection_string = f"DefaultEndpointsProtocol=https;AccountName={account_name};AccountKey={account_key};EndpointSuffix=core.windows.net"
queue_service_client = QueueServiceClient.from_connection_string(connection_string)

# Get a client to interact with a specific queue
queue_client = queue_service_client.get_queue_client(stg_name)
connection_string_tb = 'BlobEndpoint=https://demoaztest900.blob.core.windows.net/;QueueEndpoint=https://demoaztest900.queue.core.windows.net/;FileEndpoint=https://demoaztest900.file.core.windows.net/;TableEndpoint=https://demoaztest900.table.core.windows.net/;SharedAccessSignature=sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-07-21T17:25:09Z&st=2024-07-21T09:25:09Z&spr=https&sig=%2FXjHOYkSvDfL%2BsfKUFDX3WwN37mFOPdV%2BqQLrZm463o%3D'
table_name = 'demotab'

# Create a client to interact with the specific table
table_client = TableClient.from_connection_string(connection_string_tb, table_name)
try:
    # Receive messages from the queue
    messages = queue_client.receive_messages(messages_per_page=5)  # Adjust as needed

    message_count = 0  # Counter for counting messages received

    # Iterate over the messages
    for message_batch in messages.by_page():
        for message in message_batch:
            print(f"Message ID: {message.id}")
            print(f"Message Body: {message.content}")
            print(f"Dequeue Count: {message.dequeue_count}")
            print("")

            # Process the message here

            # Once processed, delete the message from the queue
            
            partition_key = 'Messagedata'  # Specify your partition key
            row_key = f"RowKey-{datetime.now().isoformat()}"

                # Create an entity dictionary with partition key, row key, and message data
            entity = {
                    'PartitionKey': partition_key,
                    'RowKey': row_key,
                    'Id': str({message.id}),  # Convert id to string (RowKey must be a string)
                    'msgbody': str({message.content}),
                    'Timestamp': datetime.now().isoformat()
            }

                # Insert the entity into the table
            table_client.upsert_entity(entity)
            queue_client.delete_message(message.id, message.pop_receipt)
            message_count += 1  # Increment the message count

    if message_count == 0:
        print(f"No messages available in the queue '{stg_name}'")
    else:
        print(f"Received {message_count} message(s) from the queue '{stg_name}'")

except ResourceNotFoundError:
    print(f"The queue '{stg_name}' does not exist or is not accessible.")
except Exception as e:
    print(f"An error occurred: {e}")
    
    
